export async function zoomIn(page) {
    const zoomPlus = "button[aria-label='Zoom in']"
    await page.waitForSelector(zoomPlus, { visible: true })
    await page.click(zoomPlus)
}


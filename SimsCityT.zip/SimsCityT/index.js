import { image_to_base64, sleep, setPuppeteer, openai } from "../utils.js";
import fs from "fs";
import jimp from "jimp";
import axios from "axios";
import path from "path";

import {
  prepareTile,
  generateTile,
  getTileSrc,
  replaceTileURL,
  highlightTile,
  fakeTileURL,
} from "./tile.js";

import { zoomIn } from "./navigation.js";

const url = "https://www.google.com/mars/";

const timeout = 2000;

(async () => {
  const puppeteer = await setPuppeteer({
    windowWidth: 1920,
    windowHeight: 1080,
    puppeteerOptions: {
      devtools: false,
    },
  });

  const { page, browser } = puppeteer;

  // page.evaluateOnNewDocument(`(${init.toString()})(window)`);

  // insert css stylesheet
  await page.goto(url, {
    waitUntil: "networkidle0",
  });

  // await zoomIn(page);

  await page.addStyleTag({ path: "./SimsCityT/style.css" });

  const imgSel = '#map img[draggable="false"][src^="https://"]';

  await page.waitForSelector(imgSel);
  let tileElems = await page.$$(imgSel);

  // limit to 10 tiles
  tileElems = tileElems.slice(0, 1);

  tileElems.forEach(async (tileElem) => {
    // const randomTile = tileElems[Math.floor(Math.random() * tileElems.length - 1)]
    const randomTile = tileElem;
    const src = await getTileSrc(page, randomTile);
    const randomName = Math.random().toString(36).substring(7);
    const stopTileAnim = await highlightTile(page, randomTile);
    const { image, mask } = await prepareTile(src, "tile_" + randomName);
    const generatedImgUrl = await generateTile(image, mask);

    await stopTileAnim(); // must be before replaceTileURL. Otherwise, load event is not triggered
    await replaceTileURL(page, randomTile, generatedImgUrl);
  });
  // // await browser.close();
})();
